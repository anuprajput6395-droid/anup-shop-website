/* =========================================================
   GOVTCAREERHUB - CLIENT JAVASCRIPT
   Handles:
   - Client Side View Routing
   - Dark/Light Mode Theme
   - Job Search & Multi-Filters
   - Bookmark Management (localStorage)
   - Admin CRUD Demo (localStorage)
   ========================================================= */

// Sample Verified Dataset (Clearly Marked as Demo Content)
const initialJobs = [
  {
    id: "JOB-101",
    org: "Staff Selection Commission (SSC)",
    post: "Combined Graduate Level (CGL) 2026",
    vacancies: "14,500 Posts",
    qualification: "Graduate",
    state: "Central",
    lastDate: "2026-10-15",
    isNew: true,
    desc: "SSC CGL examination for recruitment to Group B and Group C posts in various Ministries and Departments of the Government of India.",
    fee: "General/OBC: ₹100 | SC/ST/Female: ₹0",
    ageLimit: "18 to 32 Years (As per post norms)",
    payScale: "Pay Level 4 to Pay Level 8 (₹25,500 to ₹1,51,100)"
  },
  {
    id: "JOB-102",
    org: "Railway Recruitment Boards (RRB)",
    post: "Non-Technical Popular Categories (NTPC)",
    vacancies: "11,558 Posts",
    qualification: "Graduate",
    state: "Central",
    lastDate: "2026-10-22",
    isNew: true,
    desc: "RRB NTPC Graduate Level posts including Station Master, Goods Train Manager, Senior Commercial cum Ticket Clerk.",
    fee: "General/OBC: ₹500 (Refundable ₹400 on CBT-1) | SC/ST: ₹250",
    ageLimit: "18 to 36 Years",
    payScale: "Pay Level 5 & Level 6"
  },
  {
    id: "JOB-103",
    org: "Haryana Staff Selection Commission (HSSC)",
    post: "CET Group C Various Department Posts",
    vacancies: "6,200 Posts",
    qualification: "10th / 12th",
    state: "Haryana",
    lastDate: "2026-10-05",
    isNew: true,
    desc: "Recruitment of clerical, technical assistants and field operators across Haryana Government ministries.",
    fee: "CET Registered candidates exempt / As per HSSC norms",
    ageLimit: "18 to 42 Years",
    payScale: "Pay Level 2 to Level 6"
  },
  {
    id: "JOB-104",
    org: "Union Public Service Commission (UPSC)",
    post: "Civil Services Examination 2027 Prelims",
    vacancies: "1,105 Posts",
    qualification: "Graduate",
    state: "Central",
    lastDate: "2026-11-01",
    isNew: false,
    desc: "All India competitive examination for Indian Administrative Service, Indian Foreign Service, and Indian Police Service.",
    fee: "General: ₹100 | Female/SC/ST/PwBD: Exempted",
    ageLimit: "21 to 32 Years",
    payScale: "Pay Matrix Level 10 and above"
  },
  {
    id: "JOB-105",
    org: "Delhi Subordinate Services Selection Board (DSSSB)",
    post: "Special Education & Primary Teachers (PRT)",
    vacancies: "4,320 Posts",
    qualification: "Graduate",
    state: "Delhi",
    lastDate: "2026-10-18",
    isNew: false,
    desc: "Recruitment under Directorate of Education GNCT Delhi for primary teaching personnel.",
    fee: "General/OBC: ₹100 | SC/ST/Ex-Servicemen: ₹0",
    ageLimit: "Below 30 Years",
    payScale: "Pay Level 6 (₹35,400 - ₹1,12,400)"
  },
  {
    id: "JOB-106",
    org: "Uttar Pradesh Police Recruitment & Promotion Board",
    post: "Sub Inspector (Civil Police) & Platoon Commander",
    vacancies: "4,500 Posts",
    qualification: "Graduate",
    state: "Uttar Pradesh",
    lastDate: "2026-10-28",
    isNew: true,
    desc: "Direct recruitment for Sub Inspector of Police in UP State forces.",
    fee: "All Categories: ₹400",
    ageLimit: "21 to 28 Years",
    payScale: "Pay Band 9300-34800 (Grade Pay 4200)"
  }
];

const sampleResults = [
  { exam: "SSC CHSL (10+2) Tier 1 Result 2026", org: "SSC", date: "Sep 18, 2026", status: "Declared", linkText: "View Cut-off Marks" },
  { exam: "IBPS Clerk Prelims XIV Scorecard", org: "IBPS", date: "Sep 15, 2026", status: "Declared", linkText: "Download Scorecard" },
  { exam: "UPSC CDS (II) Written Examination List", org: "UPSC", date: "Sep 12, 2026", status: "Merit List Out", linkText: "View Qualified Roll Nos" },
  { exam: "Haryana Police Constable Physical Result", org: "HSSC", date: "Sep 10, 2026", status: "Declared", linkText: "PST / PMT Results" },
  { exam: "RRB Technician Grade I & III Final Marks", org: "RRB", date: "Sep 08, 2026", status: "Final Score", linkText: "Check Score List" }
];

const sampleAdmitCards = [
  { exam: "UPSC Civil Services Prelims 2026", org: "UPSC", examDate: "Oct 12, 2026", status: "Available Now", linkText: "Download E-Admit Card" },
  { exam: "SSC Junior Engineer (Paper-I) Exam", org: "SSC", examDate: "Oct 20, 2026", status: "City Slip Released", linkText: "Check Exam City" },
  { exam: "SBI Probationary Officer Preliminary Exam", org: "SBI", examDate: "Nov 02, 2026", status: "Available Now", linkText: "Download Call Letter" },
  { exam: "HSSC CET Group 56 & 57 Skill Test", org: "HSSC", examDate: "Oct 15, 2026", status: "Available Now", linkText: "Download Admit Card" }
];

const sampleAnswerKeys = [
  { exam: "SSC CGL Tier 1 Provisional Key 2026", date: "Sep 19, 2026", status: "Objection Active", desc: "Submit objections by paying ₹100 per question until Sep 25, 2026." },
  { exam: "NEET UG Re-Exam Final Answer Key", date: "Sep 14, 2026", status: "Final Key Out", desc: "NTA has published the revised and frozen final answer keys." },
  { exam: "Haryana CET Mains Commerce Group Key", date: "Sep 11, 2026", status: "Objection Closed", desc: "Final verification pending by subject matter panel." }
];

const sampleSyllabi = [
  { exam: "SSC CGL Detailed Exam Scheme & Pattern", subjects: "Reasoning, Quantitative Aptitude, English Comprehension, General Awareness", fileType: "PDF (Syllabus)" },
  { exam: "RRB NTPC CBT 1 & CBT 2 Complete Syllabus", subjects: "Maths (BODMAS, Algebra), General Science, Static GK, Current Affairs", fileType: "PDF (Pattern)" },
  { exam: "UPSC Civil Services GS 1 to 4 Syllabus", subjects: "History, Geography, Polity, Governance, Ethics, International Relations", fileType: "Official Document" }
];

const sampleSchemes = [
  { title: "National Means-cum-Merit Scholarship (NMMSS)", agency: "Ministry of Education", benefit: "₹12,000 / year for eligible students", category: "Education" },
  { title: "Haryana Saksham Yuva Scheme", agency: "Haryana Employment Dept", benefit: "Honorary allowance + part-time skill work", category: "Youth Welfare" },
  { title: "PM Kaushal Vikas Yojana (PMKVY 4.0)", agency: "MSDE India", benefit: "Free industry skill certification & placement aid", category: "Skill Development" }
];

// App State Management
let jobsData = [];
let bookmarks = JSON.parse(localStorage.getItem('govt_bookmarks')) || [];
const itemsPerPage = 4;
let currentJobPage = 1;

// Initialization
document.addEventListener('DOMContentLoaded', () => {
  initializeStorage();
  setupEventListeners();
  updateBookmarkCounter();
  renderAllViews();
  setupTheme();
  
  // Back to Top Listener
  window.addEventListener('scroll', () => {
    const btn = document.getElementById('backToTopBtn');
    if (window.scrollY > 300) {
      btn.classList.add('show');
    } else {
      btn.classList.remove('show');
    }
  });
});

function initializeStorage() {
  const saved = localStorage.getItem('govt_jobs_data');
  if (saved) {
    try {
      jobsData = JSON.parse(saved);
    } catch (e) {
      jobsData = [...initialJobs];
    }
  } else {
    jobsData = [...initialJobs];
    saveJobsToLocal();
  }
}

function saveJobsToLocal() {
  localStorage.setItem('govt_jobs_data', JSON.stringify(jobsData));
}

// Single-Page View Switcher
function switchTab(viewId) {
  const views = document.querySelectorAll('.app-view');
  views.forEach(v => v.classList.remove('active'));

  const targetView = document.getElementById(`view-${viewId}`);
  if (targetView) {
    targetView.classList.add('active');
  }

  // Update navigation classes
  const navLinks = document.querySelectorAll('.nav-item');
  navLinks.forEach(link => {
    if (link.getAttribute('data-tab') === viewId) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });

  // Close mobile drawer if open
  document.getElementById('mobileDrawer').style.display = 'none';
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Render All Component Data
function renderAllViews() {
  renderHomeJobs();
  renderJobTable();
  renderResults();
  renderAdmitCards();
  renderAnswerKeys();
  renderSyllabus();
  renderSchemes();
  renderAdminTable();
}

function renderHomeJobs() {
  const container = document.getElementById('homeJobsContainer');
  if (!container) return;
  const recent = jobsData.slice(0, 3);
  container.innerHTML = recent.map(j => createJobRowHtml(j)).join('');
}

function createJobRowHtml(job) {
  const isSaved = bookmarks.includes(job.id);
  return `
    <div class="job-row-card">
      <div class="job-meta-left">
        <div class="job-tags">
          ${job.isNew ? '<span class="badge badge-new"><i class="fa-solid fa-sparkles"></i> NEW</span>' : ''}
          <span class="badge badge-state">${job.state}</span>
          <span class="badge badge-vac">${job.vacancies}</span>
        </div>
        <h3 class="job-title">${job.post}</h3>
        <p class="job-org"><i class="fa-solid fa-building-columns"></i> ${job.org}</p>
        <div class="job-stats-inline">
          <span><i class="fa-solid fa-user-graduate"></i> Qual: <strong>${job.qualification}</strong></span>
          <span><i class="fa-solid fa-calendar-xmark"></i> Last Date: <strong>${job.lastDate}</strong></span>
        </div>
      </div>
      <div class="job-actions-right">
        <button class="action-icon ${isSaved ? 'saved' : ''}" onclick="toggleBookmark('${job.id}')" title="Save Job">
          <i class="fa-${isSaved ? 'solid' : 'regular'} fa-bookmark"></i>
        </button>
        <button class="action-icon" onclick="shareJob('${job.post}')" title="Share">
          <i class="fa-solid fa-share-nodes"></i>
        </button>
        <button class="btn btn-primary btn-sm" onclick="viewJobDetail('${job.id}')">View Details &rarr;</button>
      </div>
    </div>
  `;
}

// Latest Jobs Listing & Multi-Filter
function applyJobFilters() {
  currentJobPage = 1;
  renderJobTable();
}

function resetJobFilters() {
  document.getElementById('jobFilterSearch').value = '';
  document.getElementById('jobFilterState').value = 'All';
  document.getElementById('jobFilterQual').value = 'All';
  currentJobPage = 1;
  renderJobTable();
}

function renderJobTable() {
  const container = document.getElementById('jobsTableContainer');
  if (!container) return;

  const search = (document.getElementById('jobFilterSearch')?.value || '').toLowerCase().trim();
  const state = document.getElementById('jobFilterState')?.value || 'All';
  const qual = document.getElementById('jobFilterQual')?.value || 'All';

  let filtered = jobsData.filter(j => {
    const matchQuery = j.post.toLowerCase().includes(search) || j.org.toLowerCase().includes(search);
    const matchState = (state === 'All') || (j.state === state);
    const matchQual = (qual === 'All') || (j.qualification === qual);
    return matchQuery && matchState && matchQual;
  });

  if (filtered.length === 0) {
    container.innerHTML = `
      <div style="text-align: center; padding: 40px; background: var(--bg-card); border-radius: var(--radius-md); border: 1px solid var(--border-color);">
        <i class="fa-solid fa-folder-open text-orange" style="font-size: 2.5rem; margin-bottom: 12px;"></i>
        <h3>No Matching Results Found</h3>
        <p class="text-muted">Try changing your filters or searching with a different exam keyword.</p>
      </div>
    `;
    document.getElementById('jobsPagination').innerHTML = '';
    return;
  }

  // Pagination calculation
  const totalPages = Math.ceil(filtered.length / itemsPerPage);
  const startIdx = (currentJobPage - 1) * itemsPerPage;
  const paginated = filtered.slice(startIdx, startIdx + itemsPerPage);

  container.innerHTML = paginated.map(j => createJobRowHtml(j)).join('');
  renderPagination(totalPages);
}

function renderPagination(totalPages) {
  const paginationElem = document.getElementById('jobsPagination');
  if (!paginationElem) return;

  if (totalPages <= 1) {
    paginationElem.innerHTML = '';
    return;
  }

  let html = '';
  for (let i = 1; i <= totalPages; i++) {
    html += `<button class="page-btn ${i === currentJobPage ? 'active' : ''}" onclick="goToJobPage(${i})">${i}</button>`;
  }
  paginationElem.innerHTML = html;
}

function goToJobPage(page) {
  currentJobPage = page;
  renderJobTable();
  window.scrollTo({ top: 350, behavior: 'smooth' });
}

// Single Job Details View
function viewJobDetail(jobId) {
  const job = jobsData.find(j => j.id === jobId);
  if (!job) return;

  const container = document.getElementById('jobDetailContainer');
  container.innerHTML = `
    <div class="detail-header-block">
      <div class="job-tags">
        <span class="badge badge-state">${job.state}</span>
        <span class="badge badge-vac">${job.vacancies}</span>
        <span class="badge badge-new">Direct Recruitment</span>
      </div>
      <h2 style="font-size: 2rem; margin-top: 10px;">${job.post}</h2>
      <p class="text-muted" style="font-size: 1.1rem;"><i class="fa-solid fa-building-columns"></i> ${job.org}</p>
    </div>

    <div style="margin: 20px 0;">
      <h3>Summary & Notification Overview</h3>
      <p style="margin-top: 8px; color: var(--text-muted);">${job.desc}</p>
    </div>

    <table class="detail-table">
      <tbody>
        <tr>
          <th>Application End Date</th>
          <td><strong class="text-orange">${job.lastDate}</strong></td>
        </tr>
        <tr>
          <th>Minimum Educational Qualification</th>
          <td>${job.qualification}</td>
        </tr>
        <tr>
          <th>Application Fee Breakdown</th>
          <td>${job.fee || '₹100 for General / OBC; Exempted for SC/ST'}</td>
        </tr>
        <tr>
          <th>Prescribed Age Limit</th>
          <td>${job.ageLimit || '18 to 30 years as of closing date'}</td>
        </tr>
        <tr>
          <th>Pay Scale / Salary Structure</th>
          <td>${job.payScale || 'Level 4 as per 7th CPC Matrix'}</td>
        </tr>
      </tbody>
    </table>

    <div style="margin-top: 30px; display: flex; gap: 14px; flex-wrap: wrap;">
      <a href="#" class="btn btn-primary" onclick="triggerToast('Redirecting to official sample application server...')"><i class="fa-solid fa-arrow-up-right-from-square"></i> Apply Online (Demo Link)</a>
      <a href="#" class="btn btn-outline" onclick="triggerToast('Downloading demo recruitment PDF...')"><i class="fa-solid fa-file-pdf"></i> Download Official Notice PDF</a>
    </div>
  `;

  switchTab('job-details');
}

// Results, Admit Cards, Syllabi Renders
function renderResults() {
  const container = document.getElementById('resultsGrid');
  if (!container) return;
  container.innerHTML = sampleResults.map(r => `
    <div class="info-card">
      <div class="info-card-header">
        <span class="badge badge-state">${r.org}</span>
        <h3>${r.exam}</h3>
      </div>
      <div class="info-card-body">
        <div class="info-row">
          <span>Release Date:</span>
          <strong>${r.date}</strong>
        </div>
        <div class="info-row">
          <span>Result Status:</span>
          <strong style="color: #16a34a;">${r.status}</strong>
        </div>
      </div>
      <button class="btn btn-outline btn-full" onclick="triggerToast('Fetching scorecard list for ${r.exam}')"><i class="fa-solid fa-square-poll-vertical"></i> ${r.linkText}</button>
    </div>
  `).join('');
}

function renderAdmitCards() {
  const container = document.getElementById('admitCardGrid');
  if (!container) return;
  container.innerHTML = sampleAdmitCards.map(a => `
    <div class="info-card">
      <div class="info-card-header">
        <span class="badge badge-vac">${a.org}</span>
        <h3>${a.exam}</h3>
      </div>
      <div class="info-card-body">
        <div class="info-row">
          <span>Exam Date:</span>
          <strong>${a.examDate}</strong>
        </div>
        <div class="info-row">
          <span>Hall Ticket Status:</span>
          <strong style="color: var(--accent-orange);">${a.status}</strong>
        </div>
      </div>
      <button class="btn btn-primary btn-full" onclick="triggerToast('Initiating hall ticket download demo...')"><i class="fa-solid fa-download"></i> ${a.linkText}</button>
    </div>
  `).join('');
}

function renderAnswerKeys() {
  const container = document.getElementById('answerKeyGrid');
  if (!container) return;
  container.innerHTML = sampleAnswerKeys.map(k => `
    <div class="info-card">
      <div class="info-card-header">
        <span class="badge badge-new">${k.status}</span>
        <h3>${k.exam}</h3>
      </div>
      <div class="info-card-body">
        <p class="text-muted" style="font-size: 0.85rem; margin-bottom: 8px;">${k.desc}</p>
        <div class="info-row">
          <span>Issued On:</span>
          <strong>${k.date}</strong>
        </div>
      </div>
      <button class="btn btn-outline btn-full" onclick="triggerToast('Opening objection response key...')"><i class="fa-solid fa-file-signature"></i> View Answer Key & Submit Objection</button>
    </div>
  `).join('');
}

function renderSyllabus() {
  const container = document.getElementById('syllabusGrid');
  if (!container) return;
  container.innerHTML = sampleSyllabi.map(s => `
    <div class="info-card">
      <div class="info-card-header">
        <span class="badge badge-state">${s.fileType}</span>
        <h3>${s.exam}</h3>
      </div>
      <div class="info-card-body">
        <span class="text-muted">Key Subjects Covered:</span>
        <p style="margin-top: 4px; font-weight: 500;">${s.subjects}</p>
      </div>
      <button class="btn btn-outline btn-full" onclick="triggerToast('Preparing curriculum PDF...')"><i class="fa-solid fa-download"></i> Download Syllabus PDF</button>
    </div>
  `).join('');
}

function renderSchemes() {
  const container = document.getElementById('schemesGrid');
  if (!container) return;
  container.innerHTML = sampleSchemes.map(sc => `
    <div class="info-card">
      <div class="info-card-header">
        <span class="badge badge-vac">${sc.category}</span>
        <h3>${sc.title}</h3>
      </div>
      <div class="info-card-body">
        <div class="info-row">
          <span>Authority:</span>
          <strong>${sc.agency}</strong>
        </div>
        <div class="info-row">
          <span>Assistance:</span>
          <strong style="color: var(--accent-orange);">${sc.benefit}</strong>
        </div>
      </div>
      <button class="btn btn-outline btn-full" onclick="triggerToast('Loading scheme guidelines & eligibility...')"><i class="fa-solid fa-circle-info"></i> View Eligibility & Apply</button>
    </div>
  `).join('');
}

// Bookmark Storage & Modal
function toggleBookmark(jobId) {
  if (bookmarks.includes(jobId)) {
    bookmarks = bookmarks.filter(id => id !== jobId);
    triggerToast("Job removed from saved bookmarks.");
  } else {
    bookmarks.push(jobId);
    triggerToast("Job saved successfully in your bookmarks!");
  }
  localStorage.setItem('govt_bookmarks', JSON.stringify(bookmarks));
  updateBookmarkCounter();
  renderHomeJobs();
  renderJobTable();
}

function updateBookmarkCounter() {
  const badge = document.getElementById('bookmarkCount');
  if (badge) {
    badge.innerText = bookmarks.length;
  }
}

function openBookmarksModal() {
  const modal = document.getElementById('bookmarkModal');
  const container = document.getElementById('bookmarkListContainer');
  modal.classList.add('active');

  const savedJobs = jobsData.filter(j => bookmarks.includes(j.id));
  if (savedJobs.length === 0) {
    container.innerHTML = '<p class="text-muted">No saved notifications yet. Click the bookmark icon on any job card to save it.</p>';
  } else {
    container.innerHTML = savedJobs.map(j => `
      <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--border-color); padding: 10px 0;">
        <div>
          <h4 style="font-size: 0.95rem;">${j.post}</h4>
          <span class="text-muted" style="font-size: 0.8rem;">${j.org} &bull; Ends: ${j.lastDate}</span>
        </div>
        <div style="display: flex; gap: 8px;">
          <button class="btn btn-primary btn-sm" onclick="closeBookmarksModal(); viewJobDetail('${j.id}')">View</button>
          <button class="action-icon" onclick="toggleBookmark('${j.id}'); openBookmarksModal();" title="Remove"><i class="fa-solid fa-trash"></i></button>
        </div>
      </div>
    `).join('');
  }
}

function closeBookmarksModal() {
  document.getElementById('bookmarkModal').classList.remove('active');
}

// Admin Frontend CRUD Demo
function renderAdminTable() {
  const tbody = document.getElementById('adminJobTableBody');
  if (!tbody) return;
  tbody.innerHTML = jobsData.map(j => `
    <tr>
      <td>
        <strong>${j.post}</strong><br>
        <span class="text-muted">${j.org} (${j.state})</span>
      </td>
      <td>${j.lastDate}</td>
      <td>
        <button class="btn btn-outline btn-sm" style="color: #dc2626; border-color: #dc2626;" onclick="deleteJobAdmin('${j.id}')">
          <i class="fa-solid fa-trash"></i> Delete
        </button>
      </td>
    </tr>
  `).join('');
}

function handleAdminJobSubmit(e) {
  e.preventDefault();
  const newJob = {
    id: 'JOB-' + Date.now(),
    org: document.getElementById('admOrg').value,
    post: document.getElementById('admPost').value,
    vacancies: document.getElementById('admVacancies').value,
    qualification: document.getElementById('admQualification').value,
    state: document.getElementById('admState').value,
    lastDate: document.getElementById('admLastDate').value,
    desc: document.getElementById('admDesc').value,
    isNew: true
  };

  jobsData.unshift(newJob);
  saveJobsToLocal();
  renderAllViews();
  e.target.reset();
  triggerToast("New recruitment notification added successfully!");
}

function deleteJobAdmin(jobId) {
  if (confirm("Are you sure you want to remove this notice?")) {
    jobsData = jobsData.filter(j => j.id !== jobId);
    saveJobsToLocal();
    renderAllViews();
    triggerToast("Notification record deleted.");
  }
}

// Theme & Navigation Listeners
function setupEventListeners() {
  // Mobile navigation drawer toggle
  const mobileBtn = document.getElementById('mobileMenuBtn');
  const drawer = document.getElementById('mobileDrawer');
  if (mobileBtn && drawer) {
    mobileBtn.addEventListener('click', () => {
      drawer.style.display = (drawer.style.display === 'block') ? 'none' : 'block';
    });
  }

  // Theme Toggle Button
  const themeToggle = document.getElementById('themeToggleBtn');
  if (themeToggle) {
    themeToggle.addEventListener('click', toggleTheme);
  }
}

function setupTheme() {
  const savedTheme = localStorage.getItem('govt_portal_theme') || 'light';
  if (savedTheme === 'dark') {
    document.body.classList.remove('theme-light');
    document.body.classList.add('theme-dark');
    document.getElementById('themeToggleBtn').innerHTML = '<i class="fa-solid fa-sun"></i>';
  }
}

function toggleTheme() {
  const isDark = document.body.classList.contains('theme-dark');
  if (isDark) {
    document.body.classList.remove('theme-dark');
    document.body.classList.add('theme-light');
    localStorage.setItem('govt_portal_theme', 'light');
    document.getElementById('themeToggleBtn').innerHTML = '<i class="fa-solid fa-moon"></i>';
  } else {
    document.body.classList.remove('theme-light');
    document.body.classList.add('theme-dark');
    localStorage.setItem('govt_portal_theme', 'dark');
    document.getElementById('themeToggleBtn').innerHTML = '<i class="fa-solid fa-sun"></i>';
  }
}

// Hero Search Trigger
function handleHeroSearch(event) {
  if (event.key === 'Enter') {
    triggerHeroSearch();
  }
}

function triggerHeroSearch() {
  const input = document.getElementById('globalHeroInput');
  const val = input.value.trim();
  if (!val) return;

  switchTab('jobs');
  const jobFilterInput = document.getElementById('jobFilterSearch');
  if (jobFilterInput) {
    jobFilterInput.value = val;
    applyJobFilters();
  }
}

// Toast & Share Functions
function triggerToast(message) {
  const toast = document.getElementById('toast');
  toast.innerText = message;
  toast.classList.add('show');
  setTimeout(() => {
    toast.classList.remove('show');
  }, 2800);
}

function shareJob(title) {
  if (navigator.share) {
    navigator.share({
      title: title,
      text: `Check out this recruitment notification for ${title} on GovtCareerHub`,
      url: window.location.href
    }).catch(() => {});
  } else {
    navigator.clipboard.writeText(window.location.href);
    triggerToast("Link copied to clipboard!");
  }
}

function scrollToTop() {
  window.scrollTo({ top: 0, behavior: 'smooth' });
}